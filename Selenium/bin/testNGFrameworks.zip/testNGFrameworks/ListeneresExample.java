package testNGFrameworks;

import org.testng.ITestListener;

public class ListeneresExample implements ITestListener

{
}