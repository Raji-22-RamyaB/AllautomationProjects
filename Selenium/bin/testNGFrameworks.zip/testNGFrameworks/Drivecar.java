package testNGFrameworks;

import org.testng.annotations.Test;

public class Drivecar  

 {
	
	@Test
	public void startThecar()
	{
		System.out.println("Start the car");
		
	}
	@Test
	public void putfisrtGear()
	{
		System.out.println("putfisrtGear");
		
	}
	@Test
	public void putSecondGeer()
	{
		System.out.println("putSecondGeer");
		
	}
	@Test
	public void putThirdGear()
	{
		System.out.println("putThirdGear");
		
	}
	
 }
