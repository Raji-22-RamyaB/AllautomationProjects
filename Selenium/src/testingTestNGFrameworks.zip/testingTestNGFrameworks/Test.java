package testingTestNGFrameworks;

public class Test {

}
