package testCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import base.BaseClass;

public class MyMentors extends BaseClass{
	@Test(priority=0)
	public void myMentors() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.id("com.guidejunior:id/mentorFragment")).click();
		Thread.sleep(2000);

	}
	@Test(priority=1)
	public void mentors() throws InterruptedException
	{   
		driver.findElement(By.id("com.guidejunior:id/mentor_layout")).click();
		Thread.sleep(2000);
		//driver.findElements(By.className("android.widget.LinearLayout")).get(0).click();
		Thread.sleep(2000);
		driver.navigate().back();
		Thread.sleep(2000);

	}
	@Test(priority=2)
	public void getMentored() throws InterruptedException
	{
		driver.findElement(By.id("com.guidejunior:id/get_mentored")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("com.guidejunior:id/touch_outside")).click();
		Thread.sleep(2000);
		//driver.navigate().back();
		Thread.sleep(2000);


	}
	@Test(priority=3)
	public void search() throws InterruptedException
	{
		WebElement search=driver.findElement(By.id("com.guidejunior:id/search_bar"));
		search.click();
		Thread.sleep(2000);
		WebElement txt=driver.findElement(By.id("com.guidejunior:id/search_edit_text"));
		txt.click();
		Thread.sleep(2000);
		Thread.sleep(2000);
		txt.sendKeys("Avinash");
		Thread.sleep(2000);
		driver.findElements(By.className("android.widget.LinearLayout")).get(0).click();
		Thread.sleep(3000);
		driver.navigate().back();
		Thread.sleep(2000);
		driver.navigate().back();
		Thread.sleep(2000);


	}

}
