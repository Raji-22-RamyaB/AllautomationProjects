package testCases;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import base.BaseClass;

public class SignOut extends BaseClass {
	@Test(priority=0)
	public void signOut() throws InterruptedException
	{
	 driver.findElement(By.id("com.guidejunior:id/sign_out")).click();
	 Thread.sleep(2000);
	 //close
	 driver.findElement(By.id("com.guidejunior:id/negative_button")).click();
	 Thread.sleep(2000);
	 //signout
	 driver.findElement(By.id("com.guidejunior:id/positive_button")).click();
	 Thread.sleep(2000);
	}

}
