package testCases;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import base.BaseClass;
import io.appium.java_client.MobileBy;

public class Notes extends BaseClass{

	@Test(priority=0)
	public void notes() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.id("com.guidejunior:id/donationsFragment")).click();
		Thread.sleep(2000);


	}
	@Test(priority=1)

	public void enquire() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(MobileBy.AndroidUIAutomator
				("new UiScrollable(new UiSelector().scrollable(true)).scrollToEnd(50000)"));
		Thread.sleep(5000);
		driver.navigate().back();
		Thread.sleep(2000);
	}

}
