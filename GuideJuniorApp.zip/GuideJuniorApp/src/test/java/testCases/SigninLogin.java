package testCases;

import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.BaseClass;

public class SigninLogin extends BaseClass{


	WebElement mailid;
	WebElement password;
	WebElement loginButton;


	@BeforeClass
	public void LoginByMail() throws InterruptedException
	{

		mailid=driver.findElement(By.id("com.guidejunior:id/email_input"));
		password=driver.findElement(By.id("com.guidejunior:id/password_input"));
		loginButton=driver.findElement(By.id("com.guidejunior:id/sign_in_btn"));

	}
	/* driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
     Thread.sleep(2000);
     driver.findElement(By.id("com.guidejunior:id/email_input")).click();
    Thread.sleep(2000);
     driver.findElement(By.id("com.guidejunior:id/email_input")).sendKeys(properties.getProperty("mailid"));
     Thread.sleep(2000);
     driver.findElement(By.id("com.guidejunior:id/password_input")).click();
     Thread.sleep(2000);
     driver.findElement(By.id("com.guidejunior:id/password_input")).sendKeys(properties.getProperty("password"));
     Thread.sleep(2000);
     driver.findElement(By.id("com.guidejunior:id/sign_in_btn")).click();
     Thread.sleep(4000);
	 */


	@Test(priority=0, groups="Login")
	public void checkLoginForEmptyTextBox() throws InterruptedException
	{
		SoftAssert softAssert= new SoftAssert();

		loginButton.click();
		softAssert.assertTrue(mailid.isDisplayed(), "Usermailid empty message not displayed");
		softAssert.assertTrue(password.isDisplayed(),"Password empty message not displayed");
		softAssert.assertAll();
		Thread.sleep(2000);

	}

	@Test(priority=1, groups="Login")
	public void checkLoginForEmptyPassword()
	{
		mailid.sendKeys("raji@gmail.com");
		SoftAssert softAssert=new SoftAssert();
		loginButton.click();
		softAssert.assertEquals(mailid.isDisplayed(), true, "mailid empty message displayed for enter mailid");
		softAssert.assertEquals(password.isDisplayed(), true, "password empty message not displayed");
		softAssert.assertAll();
	}

	@Test(priority = 2, groups = "Login")
	public void checkLoginForEmptyMailid() throws InterruptedException {     
		mailid.clear();
		password.sendKeys("Raji283!");
		SoftAssert softAssert = new SoftAssert();
		loginButton.click();
		softAssert.assertEquals(mailid.isDisplayed(), true, "mailid empty message not displayed");
		softAssert.assertEquals(password.isDisplayed(), true, "Password empty message displayed for input password");
		softAssert.assertAll();
		Thread.sleep(2000);
	}

	@Test(priority=3, groups="Login")
	public void checkLoginForWrongCredential() throws InterruptedException {
		SoftAssert softAssert=new SoftAssert();
		mailid.sendKeys("raji");
		password.sendKeys("raji");
		loginButton.click();
		softAssert.assertTrue(!mailid.isDisplayed() && !password.isDisplayed());
		Wait<WebDriver> wait =new FluentWait<WebDriver>(driver)  // Fluent Wait
				.withTimeout(Duration.ofSeconds(10)).pollingEvery(Duration.ofSeconds(2))
				.withMessage("Login with wrong credential").ignoring(NoSuchElementException.class);

		softAssert.assertTrue(wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.id("com.guidejunior:id/sign_up"))).isDisplayed());


		softAssert.assertAll();	
		Thread.sleep(2000);
	}
	@Test(priority=4, groups="Login")
	public void CheckLoginForCorrectCredential() throws InterruptedException
	{
		mailid.clear();
		Thread.sleep(2000);
		password.clear();
		Thread.sleep(2000);
		mailid.sendKeys("raji@gmail.com");
		Thread.sleep(2000);
		password.sendKeys("Raji283!");
		Thread.sleep(2000);
		loginButton.click();
		Thread.sleep(5000);	}




	/* @Parameters({ "userType" })
	@Test(priority = 4, groups = "Login")
	public void checkLoginForCorrectCredential1(String userType) throws InterruptedException {
		mailid.clear();
		Thread.sleep(2000);
		password.clear();
		Thread.sleep(2000);
		String userName = "";
		String password1 = "";
		System.out.println(userType);
		switch (userType) {
		case "student":
			userName = properties.getProperty("mailid");
			password1 = properties.getProperty("password");
			break;
		/*case "teacher":
			userName = properties.getProperty("teacherUserName");
			password1 = properties.getProperty("teacherPassword");
			break;
		case "staff":
			userName = properties.getProperty("staffUserName");
			password1 = properties.getProperty("staffPassword");
			break;
		case "salesmanager":
			userName = properties.getProperty("salesmanagerUserName");
			password1 = properties.getProperty("salesmanagerPassword");
			break;
		case "techadmin":
			userName = properties.getProperty("techadminUserName");
			password1 = properties.getProperty("techadminPassword");
			break;  

}*/
	/*mailid.sendKeys(userName);
		password.sendKeys(password1);
		loginButton.click();

		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver) // Fluent Wait
				.withTimeout(Duration.ofSeconds(10)).pollingEvery(Duration.ofSeconds(5))
				.withMessage("Invalid Username or password").ignoring(NoSuchElementException.class);
		Assert.assertTrue(wait
				.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//*[@id='header_content']/div/h5/span[1]")))
				.getText().contains("Welcome"));

	}*/
}



