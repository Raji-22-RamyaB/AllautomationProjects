package testCases;

import java.io.IOException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

public class Signup {
	public static AndroidDriver<WebElement> driver;

	@Test
	public static void appiumSetup() throws IOException, InterruptedException
	{

		DesiredCapabilities dc=new DesiredCapabilities();
		dc.setCapability("DeviceName", "INTEX_AQUA_LIONS_3");
		dc.setCapability("udId", "FEZLG6I7QSCYN7FA");
		dc.setCapability("platformName", "Android");
		dc.setCapability("platformVersion", "7.0");
		dc.setCapability("appPackage", "com.guidejunior");
		dc.setCapability("appActivity", "com.guidejunior.ui.router.RouterActivity");
		URL url=new URL("http://127.0.0.1:4723/wd/hub");
		driver= new AndroidDriver<WebElement>(url, dc);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	}



}
