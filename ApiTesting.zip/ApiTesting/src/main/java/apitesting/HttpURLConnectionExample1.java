package apitesting;

public class HttpURLConnectionExample1 {

	
	
	
}
